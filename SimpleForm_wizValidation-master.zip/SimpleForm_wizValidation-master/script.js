/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "hi" in the browser's dev tools console
console.log('Hello INFSCI 2560!');
//Actually don't what this code mean and use- -


function check_data(){
  
  var sex=document.getElementsByName("Sex");
  if(sex[0].checked || sex[1].checked){
  }else{
    alert("You must choose as male or female!");
    return false;
  }
    
  var cellphone=document.getElementById('cellphone').value;
  var phoneno=/^\d{10}$/;

  if (!cellphone.match(phoneno)){
    alert("Your phone number should follow the format,10 digits number with no other symbol!");
    return false;
  }
  
  var email=document.getElementById('emailaddress').value;
  var remail=/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/;
  if (!email.match(remail)){
    alert("Wrong email style! You should follow the regular expression. Please provide a valid email-address!");
    return false;
  }
  return true;
  //All things works well here!
}


// function store_data(){
//       var first_name=document.getElementById('first_name').value;
//       var last_name=document.getElementById('last_name').value;
//       var sex=document.getElementsByName("Sex");
//       var sexchoice;
//       for (var i=0;i< sex.length;i++){
//         if (sex[i].checked){
//           sexchoice=sex[i].value;
//           break;
//         }
//       }
//       var birth_date=document.getElementById('birth_date').value;
//       var cellphone=document.getElementById('cellphone').value;
//       var email=document.getElementById('emailaddress').value;
//       var shoestyle=document.getElementById('shoestyle').value;

//       localStorage.setItem("firstname",first_name);
//       localStorage.setItem("lastname",last_name);
//       localStorage.setItem("sex",sexchoice);
//       localStorage.setItem("birthdate",birth_date);
//       localStorage.setItem("cellphone",cellphone);
//       localStorage.setItem("email",email);
//       localStorage.setItem("shoestyle",shoestyle);

//       var fn=localStorage.getItem("firstname");
//       var ln=localStorage.getItem("lastname");
//       var s=localStorage.getItem("sex");
//       var bd=localStorage.getItem("birthdate");
//       var cell=localStorage.getItem("cellphone");
//       var e=localStorage.getItem("email");
//       var ss=localStorage.getItem("shoestyle");
  
//       document.getElementById('dataarea').innerHTML="Here"//fn+","+ln+"|"+s+"|"+bd+"|"+cell+"|"+e+"|"+ss;
//     }

window.addEventListener("load",function() { // add a "submit" listener to a form element with id "my-form" 
  document.getElementById('my-form').addEventListener("submit",function(e) { // this code will prevent the form submission  
    e.preventDefault();// before the code /* do what you want with the form here*/// Should be triggered on form submit 
    //e.store_data;
    var first_name=document.getElementById('first_name').value;
      var last_name=document.getElementById('last_name').value;
      var sex=document.getElementsByName("Sex");
      var sexchoice;
      for (var i=0;i< sex.length;i++){
        if (sex[i].checked){
          sexchoice=sex[i].value;
          break;
        }
      }
      var birth_date=document.getElementById('birth_date').value;
      var cellphone=document.getElementById('cellphone').value;
      var email=document.getElementById('emailaddress').value;
      var shoestyle=document.getElementById('shoestyle').value;

//       localStorage.setItem("firstname",first_name);
//       localStorage.setItem("lastname",last_name);
//       localStorage.setItem("sex",sexchoice);
//       localStorage.setItem("birthdate",birth_date);
//       localStorage.setItem("cellphone",cellphone);
//       localStorage.setItem("email",email);
//       localStorage.setItem("shoestyle",shoestyle);

//       var fn=localStorage.getItem("firstname");
//       var ln=localStorage.getItem("lastname");
//       var s=localStorage.getItem("sex");
//       var bd=localStorage.getItem("birthdate");
//       var cell=localStorage.getItem("cellphone");
//       var e=localStorage.getItem("email");
//       var ss=localStorage.getItem("shoestyle");
    
//       document.getElementById('dataarea').innerHTML=fn+","+ln+"|"+s+"|"+bd+"|"+cell+"|"+e+"|"+ss;
      var raffle=new Object();
      raffle.FIRST_NAME=first_name;
      raffle.LAST_NAME=last_name;
      raffle.SEX=sexchoice;
      raffle.DATE_OF_BIRTH=birth_date;
      raffle.PHONE_NUM=cellphone;
      raffle.EMAIL=email;
      raffle.SHOE_STYLE=shoestyle;
  
      localStorage.setItem(email,JSON.stringify(raffle));
      //read all the information from local storage
      var values=[];
      var keys=Object.keys(localStorage);
      for(var i=0; i<keys.length; i++){
        var item=localStorage.getItem(keys[i])
        item=item.replace(/\"/g, "");
        values.push(item)
      }
      document.getElementById('dataarea').innerHTML=values;
    
      console.log('Form Submitted'); });}); 


