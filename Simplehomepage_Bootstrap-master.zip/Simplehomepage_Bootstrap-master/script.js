/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "hi" in the browser's dev tools console
console.log('hi');

window.onload=function(){
  var page_name=location.pathname;
  //Get the name of the page.
  page_name=page_name.split("/").pop().match(/(\S*)\./)[1];
  var navi=document.getElementsByClassName("nav-link");
  for (var i=0;i<navi.length;i++){
    if (navi[i].innerHTML==page_name){
      //How to use bootstrap to make the list-group-item active 
      navi[i].style.cssText="text-decoration:underline";
      navi[i].className="nav-link active";
    }
    else{
      navi[i].className="nav-link"
    }
  }
}

// This function is for the original NavBar
// window.onload=function(){
//   var page_name=location.pathname;
//   //Get the name of the page.
//   page_name=page_name.split("/").pop().match(/(\S*)\./)[1];
//   var navi=document.getElementsByClassName("list-group-item");
//   for (var i=0;i<navi.length;i++){
//     if (navi[i].innerHTML==page_name){
//       //How to use bootstrap to make the list-group-item active 
//       navi[i].style.cssText="text-decoration:underline";
//       navi[i].className="list-group-item list-group-item-action list-group-item-warning text-sm-center active";
//     }
//     else{
//       navi[i].className="list-group-item list-group-item-action list-group-item-warning text-sm-center"
//     }
//   }
// }


window.addEventListener("load",function() { // add a "submit" listener to a form element with id "my-form"
  var page_name=location.pathname;
  //Get the name of the page.
  page_name=page_name.split("/").pop().match(/(\S*)\./)[1];
  if(page_name=="Contact"){
    document.getElementById('form').addEventListener("submit",function(e) { // this code will prevent the form submission  
      e.preventDefault();
      var email=document.getElementById('email').value;
      var text=document.getElementById('text').value;
      localStorage.setItem("email",email);
      localStorage.setItem("text",text);
      alert("Suggestion submitted!");
  });
  }
});

function show_shadow(){
  var photo=document.getElementById("photo");
  photo.style.cssText="box-shadow:50px 20px 1px 1px rgba(128,64,0,0.5)";
}

function shadow_disappear(){
  var photo=document.getElementById("photo");
  photo.style.cssText="box-shadow:none";
}

window.addEventListener("load",function() { // add a "submit" listener to a form element with id "my-form"
  var page_name=location.pathname;
  //Get the name of the page.
  page_name=page_name.split("/").pop().match(/(\S*)\./)[1];
  if(page_name=="Home"){
    var photo=document.getElementById("photo");
    photo.addEventListener("mouseover",show_shadow);
    photo.addEventListener("mouseout",shadow_disappear);}
});

