/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "hi" in the browser's dev tools console
console.log('Hello INFSCI 2560!');


// Task 1 - Selecting Elements
function button_one_function(){
  console.log("Button one clicked!");
  //Put your code here
  document.getElementById('myelement').style.display="block"
  var MyElement=document.getElementById('em').innerHTML;
  //var MyPreElement=document.getElementsByClassName('buttons')[0];
  //var elepara=document.createElement("p");
  //var text=document.createTextNode(MyElement);
  //elepara.appendChild(text);
  //document.insertAfter(elepara,MyPreElement);
  //Note:I have tried the way in course PPT, I just cannot figure out why this does't work - -
  document.getElementById('myelement').innerHTML=MyElement;
  }
const button1 = document.getElementById("button-one");
button1.addEventListener('click', button_one_function);
button1.addEventListener('click', cancel2);
button1.addEventListener('click', cancel3);

// Task 2 - Styling Tables
function button_two_function(){
  console.log("Button two clicked!");
// Put your code here  
  var myTableRow=document.querySelectorAll("tr");
  var i;
  for(i=1;i<myTableRow.length;i=i+2){
    myTableRow[i+1].style.backgroundColor="rgb(202,220,249)";
  }  
}
const button2 = document.getElementById("button-two");
button2.addEventListener('click', button_two_function);
button2.addEventListener('click', cancel1);
button2.addEventListener('click', cancel3);


//Task 3 - Modify Grocery List
function button_three_function(){
  console.log("Button three clicked!");
// Your code here
  document.getElementsByTagName("li")[0].style.textDecoration="line-through";
  var li1=document.createElement("li");
  var text1=document.createTextNode("Grapes");
  li1.appendChild(text1);
  var li2=document.createElement("li");
  var text2=document.createTextNode("Milk");
  li2.appendChild(text2);
  document.getElementsByTagName("ul")[0].appendChild(li1);
  document.getElementsByTagName("ul")[0].appendChild(li2);
}
const button3 = document.getElementById("button-three");
button3.addEventListener('click', button_three_function);
button3.addEventListener('click', cancel1);
button3.addEventListener('click', cancel2);
//button3.on("click","button3",button_three_function);


// Task 4 - Adding Interactivity
function button_four_function(){
  cancel1();
  cancel2();
  cancel3();
}
const button4 = document.getElementById("button-four");
button4.addEventListener('click', button_four_function);
// Your code here
function cancel1(){
  document.getElementById('myelement').style.display="none ";
}
function cancel2(){
  var myTableRow=document.querySelectorAll("tr");
  var i;
  for(i=1;i<myTableRow.length;i=i+2){
    myTableRow[i+1].style.backgroundColor="rgb(255,255,255)";
  }  
}
function cancel3(){
  document.getElementsByTagName("li")[0].style.textDecoration="none";
  var child1=document.getElementsByTagName("li")[4];
  var child2=document.getElementsByTagName("li")[5];
  child1.parentNode.removeChild(child1);
  child2.parentNode.removeChild(child2);
}