//this is a helper method to create a DOM node
function createNode(element) {
      return document.createElement(element);
  }

function append(parent, element) {
    return parent.appendChild(element);
  }

const ul=document.getElementById('person');                                                                                                                                                                                                                                                                                                                         


  fetch("https://randomuser.me/api/?results=10&?name")
  .then (function(response){
    return response.json()
  })
  .then(function(myJson){
    
    for (var l=0; l<10;l++){
      var lii=createNode("li");
      append(ul,lii);
    }
    //add li
    var li=document.getElementsByTagName("li");
    for (var h=0;h<10;h++){
      li[h].className="col-4 list-group-item float-left d-flex flex-column justify-content-center border-left-0 border-right-0 border-top-0";
      append(li[h],createNode("img"));
      append(li[h],createNode("h4"));
    }
    // add li's class and add img and h4 in every li
    
    var name=[];
    var picture=[];
    for (var i=0;i<10;i++){
      name[i]=myJson.results[i].name.title+" "+myJson.results[i].name.first+" "+myJson.results[i].name.last;
      picture[i]=myJson.results[i].picture.large;
    }
    //get name from returned json file
    
    var namearea=document.getElementsByTagName("h4");
    var picturearea=document.getElementsByTagName("img");
    for (var k=0;k<10;k++){
      namearea[k].innerHTML=name[k];
      namearea[k].className="font-weight-light mx-auto"
      picturearea[k].className="border rounded mx-auto my-2";
      picturearea[k].height="200";
      picturearea[k].width="200"
      picturearea[k].src=picture[k];
    }
    //add innerHTML and class and src for h and img tag, innerHTML and src from json
  })


//feel free to use the helper code above ... or take a different approach
